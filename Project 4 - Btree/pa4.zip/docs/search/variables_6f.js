var searchData=
[
  ['open_5fcounts_5f',['open_counts_',['../classbadgerdb_1_1_file.html#ae57b911c2c587ba333c68de3e6c8fca7',1,'badgerdb::File']]],
  ['open_5fstreams_5f',['open_streams_',['../classbadgerdb_1_1_file.html#a57d3ea6df7cc17bb0ea9119264dd49c3',1,'badgerdb::File']]]
];
